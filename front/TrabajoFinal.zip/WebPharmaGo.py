from flask import Flask, render_template, jsonify, request, session
from datetime import timedelta
import uuid
import sqlite3
import json
import logging
from datetime import datetime

# Configuración del logging
logging.basicConfig(
    filename='chat_history.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

app = Flask(__name__)
# Configura una clave secreta para las sesiones
app.secret_key = 'Pajaritos3nIaIuna'  # Cambia esto por una clave segura
# Configura el tiempo de vida de la sesión
app.permanent_session_lifetime = timedelta(minutes=60)

def get_db_connection():
    conn = sqlite3.connect('TrabajoFinal/Base/farmacias_turno.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_regions')
def get_regions():
    conn = get_db_connection()
    regions = conn.execute('''
        SELECT DISTINCT nombre_region 
        FROM farmacias 
        WHERE nombre_region IS NOT NULL 
        ORDER BY nombre_region
    ''').fetchall()
    conn.close()
    return jsonify([region['nombre_region'] for region in regions])

@app.route('/get_comunas/<region>')
def get_comunas(region):
    conn = get_db_connection()
    comunas = conn.execute('''
        SELECT DISTINCT comuna_nombre 
        FROM farmacias 
        WHERE nombre_region = ? 
        AND comuna_nombre IS NOT NULL 
        ORDER BY comuna_nombre
    ''', (region,)).fetchall()
    conn.close()
    return jsonify([comuna['comuna_nombre'] for comuna in comunas])

@app.route('/search_farmacias/<region>/<comuna>')
def search_farmacias(region, comuna):
    conn = get_db_connection()
    farmacias = conn.execute('''
        SELECT local_nombre, localidad_nombre, local_direccion, 
               de_turno, URL_direccion as url_direccion
        FROM farmacias 
        WHERE nombre_region = ? 
        AND comuna_nombre = ?
        ORDER BY de_turno DESC, local_nombre
    ''', (region, comuna)).fetchall()
    conn.close()
    
    return jsonify([dict(farmacia) for farmacia in farmacias])

class ChatSession:
    def __init__(self):
        self.conversation_history = []
        self.created_at = datetime.now()

    def add_message(self, role, content):
        self.conversation_history.append({
            'role': role,
            'content': content,
            'timestamp': datetime.now().isoformat()
        })

    def get_history(self):
        return self.conversation_history

    def clear_history(self):
        self.conversation_history = []

# Diccionario para almacenar las sesiones activas
chat_sessions = {}

def get_or_create_chat_session():
    """Obtiene o crea una nueva sesión de chat"""
    if 'chat_sid' not in session:
        # Genera un nuevo SID si no existe
        session['chat_sid'] = str(uuid.uuid4())
        session.permanent = True  # Hace que la sesión expire según permanent_session_lifetime
    
    sid = session['chat_sid']
    
    # Crear nueva sesión de chat si no existe o expiró
    if sid not in chat_sessions:
        chat_sessions[sid] = ChatSession()
    
    return chat_sessions[sid]

def cleanup_old_sessions():
    """Limpia las sesiones antiguas"""
    current_time = datetime.now()
    for sid in list(chat_sessions.keys()):
        session_age = current_time - chat_sessions[sid].created_at
        if session_age > timedelta(minutes=60):
            del chat_sessions[sid]

@app.route('/chat', methods=['POST'])
def chat():
    try:
        # Obtener la sesión actual
        chat_session = get_or_create_chat_session()
        current_sid = session['chat_sid']
        
        print(f"\n=== Chat Session ID: {current_sid} ===")  # Debug log
        print("Chat endpoint called")
        data = request.get_json()
        print("Received data:", data)
        
        # Logging a archivo
        logging.info(f"=== New chat message for Session ID: {current_sid} ===")
        
        if not data or 'message' not in data:
            print("No message in request")
            logging.warning(f"Session {current_sid}: No message in request")
            return jsonify({'error': 'No message provided'}), 400

        user_message = data['message'].strip()
        if not user_message:
            print("Empty message")
            logging.warning(f"Session {current_sid}: Empty message received")
            return jsonify({'error': 'Empty message'}), 400

        # Por ahora, solo eco del mensaje
        response = f"Recibí tu mensaje: {user_message}"
        print(f"Sending response for session {current_sid}:", response)
        logging.info(f"Session {current_sid} - User message: {user_message}")
        logging.info(f"Session {current_sid} - Bot response: {response}")

        return jsonify({
            'response': response,
            'session_id': current_sid  # Agregamos el SID en la respuesta
        })

    except Exception as e:
        error_msg = f"Error in chat endpoint: {str(e)}"
        print(error_msg)
        logging.error(f"Session {session.get('chat_sid', 'UNKNOWN')}: {error_msg}")
        return jsonify({'error': str(e)}), 500

def save_chat_history(session_id, history):
    """Guarda el historial del chat en la base de datos"""
    try:
        conn = get_db_connection()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                session_id TEXT,
                history TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Actualizar o insertar el historial
        conn.execute('''
            INSERT OR REPLACE INTO chat_history (session_id, history, updated_at)
            VALUES (?, ?, CURRENT_TIMESTAMP)
        ''', (session_id, json.dumps(history)))
        
        conn.commit()
        logging.info(f"Chat history saved successfully for session {session_id}")
        print(f"Chat history saved for session {session_id}")
    except Exception as e:
        error_msg = f"Error saving chat history: {e}"
        logging.error(f"Session {session_id}: {error_msg}")
        print(error_msg)
    finally:
        if conn:
            conn.close()

@app.route('/chat/history', methods=['GET'])
def get_chat_history():
    """Endpoint para obtener el historial del chat"""
    chat_session = get_or_create_chat_session()
    return jsonify({
        'session_id': session['chat_sid'],
        'history': chat_session.get_history()
    })

@app.route('/chat/clear', methods=['POST'])
def clear_chat_history():
    """Endpoint para limpiar el historial del chat"""
    chat_session = get_or_create_chat_session()
    chat_session.clear_history()
    return jsonify({'message': 'Chat history cleared'})

if __name__ == '__main__':
    app.run(debug=True)
